ecen410p1_intercell_analysis.m simulates for different transmit powers, constant number of users.
ecen410p1_user_analysis.m simulates for a constant transmit power, a variable number of users